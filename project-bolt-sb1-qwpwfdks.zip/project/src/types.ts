export interface SocialTasks {
  platforms: {
    facebook: string;
    instagram: string;
    linkedin: string;
  };
  generatedDate: string;
}